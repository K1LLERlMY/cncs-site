'use strict';
// Verified archival pictures; every photo retains its original source link.
window.CNCS_HISTORY_MEDIA = {
  "covers": {
    "classic": {
      "file": "assets/history/wnv-team-2005.jpg",
      "alt": "wNv 队员在 WEG 2005 总决赛夺冠后捧杯合影",
      "caption": "wNv · 2005 年 WEG 夺冠合照",
      "sourcePage": "https://www.csgo.com.cn/news/gamemedia/20170310/201208.shtml",
      "credit": "图源：CS:GO 国服官方网站历史回顾；原摄影未署名",
      "width": 400,
      "height": 300,
      "objectPosition": "50% 40%"
    },
    "csgo": {
      "file": "assets/history/tyloo-team-2016.jpg",
      "alt": "2016 年底年度专访中刊载的 TYLOO 战队及教练合影，身后是天禄俱乐部标志",
      "caption": "TYLOO · 2016 年度专访合影",
      "sourcePage": "https://www.csgo.com.cn/news/gamemedia/20161216/198627.shtml",
      "credit": "图源：ImbaTV／CS:GO 国服官方网站转载",
      "width": 600,
      "height": 390,
      "objectPosition": "50% 35%"
    },
    "cs2": {
      "file": "assets/history/lvg-copenhagen-2024.webp",
      "alt": "Lynn Vision 队员在 2024 哥本哈根 Major 亚洲 RMR 晋级后欢呼",
      "caption": "Lynn Vision · 2024 亚洲 RMR",
      "sourcePage": "https://csgo.5eplay.com/article/240229bzapw1",
      "width": 800,
      "height": 533,
      "objectPosition": "50% 35%"
    }
  },
  "moments": {
    "classic": {
      "2005.12": {
        "file": "assets/history/wnv-weg-2005.jpg",
        "alt": "wNv 队员在 WEG 2005 总决赛舞台上庆祝夺冠，背景写有 WEG 2005 Grand Finals",
        "caption": "北京 · WEG 2005 总决赛夺冠现场",
        "sourcePage": "https://www.csgo.com.cn/article/details/20180605/211571.html",
        "credit": "图源：CS:GO 国服官方网站；原摄影未署名",
        "width": 600,
        "height": 426,
        "objectPosition": "50% 45%"
      }
    },
    "csgo": {
      "2016.04": {
        "file": "assets/history/tyloo-malmo-2016.webp",
        "alt": "TYLOO 队员在 2016 年马尔默大师赛击败 Luminosity 后握拳庆祝",
        "caption": "马尔默 2016 · 击败 Luminosity 后的庆祝",
        "sourcePage": "https://www.csgo.com.cn/news/gamemedia/20161216/198627.shtml",
        "credit": "图源：ImbaTV／CS:GO 国服官方网站转载",
        "width": 600,
        "height": 450,
        "objectPosition": "50% 45%"
      },
      "2017.09": {
        "file": "assets/history/csgo-china-launch-2017.jpg",
        "alt": "2017 年 CS:GO 国服正式公测官方海报，文字为国服今日公测",
        "caption": "2017.09.15 · 国服正式公测",
        "sourcePage": "https://www.csgo.com.cn/news/gamenews/20170914/206276.shtml",
        "credit": "图源：完美世界／CS:GO 国服官方网站",
        "width": 1267,
        "height": 715,
        "objectPosition": "50% 50%"
      },
      "2018.05": {
        "file": "assets/history/tyloo-sydney-2018.webp",
        "alt": "2018 年 IEM 悉尼站 TYLOO 比赛转播画面，选手在 Inferno 持枪推进",
        "caption": "IEM Sydney 2018 · 比赛转播画面",
        "sourcePage": "https://www.csgo.com.cn/article/details/20190104/213001.html",
        "credit": "图源：CS:GO 国服官方网站年度回顾（转播静帧）",
        "width": 320,
        "height": 180,
        "objectPosition": "50% 50%"
      },
      "2018.09": {
        "file": "assets/history/tyloo-london-2018.jpg",
        "alt": "TYLOO 2018 年伦敦 Major 晋级新传奇阶段海报，包含当届五名选手及 Qualified for Legends Stage 字样",
        "caption": "伦敦 2018 · 晋级新传奇阶段",
        "sourcePage": "https://www.csgo.com.cn/article/details/20190104/213001.html",
        "credit": "图源：CS:GO 国服官方网站年度回顾",
        "width": 600,
        "height": 544,
        "objectPosition": "50% 35%"
      }
    },
    "cs2": {
      "2024.02": {
        "file": "assets/history/lvg-copenhagen-2024.webp",
        "alt": "Lynn Vision 队员在 2024 哥本哈根 Major 亚洲 RMR 晋级后欢呼",
        "caption": "2024 亚洲 RMR · LVG 首次晋级 Major｜摄影：HLTV，图片由 5EPlay 报道转载",
        "sourcePage": "https://csgo.5eplay.com/article/240229bzapw1",
        "width": 800,
        "height": 533
      },
      "2024.11—12": {
        "file": "assets/crowd.webp",
        "alt": "2024 完美世界上海 Major 现场观众与赛场",
        "caption": "2024 上海 Major · 中国主场｜完美世界电竞",
        "sourcePage": "https://www.csgo.com.cn/article/details/20241216/225790.html",
        "width": 1600,
        "height": 1067
      },
      "2024.12": {
        "file": "assets/history/ra-shanghai-2024.webp",
        "alt": "Rare Atom 在 2024 上海 Major 战胜 fnatic 后向主场观众鞠躬致谢",
        "caption": "2024 上海 Major · RA 战胜 fnatic 后谢场｜摄影：完美世界电竞，via esports.gg",
        "sourcePage": "https://esports.gg/news/counter-strike-2/rare-atom-eliminate-fnatic-from-shanghai-major/",
        "width": 1280,
        "height": 720
      },
      "2025.06": {
        "file": "assets/history/lvg-austin-2025.webp",
        "alt": "Lynn Vision 队员在 2025 奥斯汀 Major 比赛现场握拳欢呼",
        "caption": "2025 奥斯汀 Major · LVG 晋级报道配图｜BLAST 官方",
        "sourcePage": "https://blast.tv/cs/news/lynn-vision-advance-to-stage-3-with-2-1-win-over-b8",
        "width": 1280,
        "height": 853
      },
      "2025.07": {
        "file": "assets/tyloo-fissure-2025-poster.webp",
        "alt": "TYLOO 在 2025 FISSURE Playground 1 冠军庆典上举杯",
        "caption": "2025 贝尔格莱德 · TYLOO 捧杯｜TYLOO 俱乐部官方视频截帧",
        "sourcePage": "https://www.bilibili.com/video/BV1aKgYz9E5P/",
        "width": 1280,
        "height": 720
      }
    }
  }
};
