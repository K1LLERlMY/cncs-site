'use strict';
(() => {
  const list=document.getElementById('match-list');
  const status=document.getElementById('feed-status');
  const filter=document.getElementById('team-filter');
  const refresh=document.getElementById('refresh-feed');
  const tabs=[...document.querySelectorAll('[data-feed]')];
  const localFile=location.protocol==='file:';
  const configuredFeed=document.querySelector('meta[name="cncs-feed-url"]')?.getAttribute('content')?.trim();
  const feedUrl=configuredFeed?new URL(configuredFeed,document.baseURI).href:'/api/live';
  const apiLink=document.getElementById('feed-api-link');
  if(apiLink&&!localFile)apiLink.href=feedUrl;
  const onlineUrl='https://cncs.chat/#live';
  const teamLogos={4863:'assets/logos/tyloo-20261009.webp',8840:'assets/logos/lynn-vision-20261009-512.webp',11514:'assets/logos/rare-atom-20261009.svg'};
  let data=null,active='upcoming',loading=false,requestError=false;
  const formatter=new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false});
  const validTime=value=>typeof value==='string'&&Number.isFinite(Date.parse(value));
  const date=value=>validTime(value)?formatter.format(new Date(value)):'时间待定';
  const age=value=>validTime(value)?Date.now()-Date.parse(value):Infinity;
  const el=(tag,className,text)=>{const node=document.createElement(tag);if(className)node.className=className;if(text!==undefined)node.textContent=text;return node;};
  function teamElement(team,cnIds) {
    const block=el('span','match-team-block');
    const logo=teamLogos[team.id];
    if(logo){const img=el('img','match-team-logo');img.src=logo;img.alt='';img.width=32;img.height=32;img.loading='lazy';img.addEventListener('error',()=>img.remove(),{once:true});block.append(img);}
    const name=el('span','match-team-label',team.name);block.append(name);
    if(cnIds.has(team.id)) block.append(el('small','cn-label','CN'));
    return block;
  }
  function draw() {
    if(!data)return;
    const staticArchive=data.deliveryMode==='static-archive';
    const cnIds=new Set(data.teams.map(team=>team.id));
    const selected=filter.value;
    const group=data[active];
    const items=(group?.matches||[]).filter(match=>selected==='all'||match.team1.id===Number(selected)||match.team2.id===Number(selected));
    document.getElementById('upcoming-count').textContent=String(data.upcoming.matches.length);
    document.getElementById('results-count').textContent=String(data.results.matches.length);
    list.replaceChildren();
    list.setAttribute('aria-busy','false');
    const checkAge=age(group?.checkedAt);
    const stale=checkAge>35*60*1000;
    status.classList.toggle('is-stale',stale||requestError||!!data.lastError||!!data.storageUnavailable);
    const label=validTime(group?.checkedAt)?`HLTV 核对于 ${date(group.checkedAt)}`:'尚未成功读取这个分类';
    status.textContent=`${localFile?'本地文件 · 已核实存档 · ':staticArchive?'静态发布 · 已核实存档 · ':''}${label}（北京时间）${stale?' · 数据较旧，等待核对':group.coverage==='partial'?' · 当前为已核实的部分记录':''}${!localFile&&(requestError||data.storageUnavailable)?staticArchive?' · 存档读取失败，显示上次已核实数据':' · 更新服务连接失败，显示已核实存档':data.lastError?' · 来源暂时不可读':''}`;
    if(!items.length){const verified=group.coverage==='complete'&&!stale;list.append(el('div','feed-empty',active==='upcoming'?(verified?'HLTV 暂未公布这支战队的后续对阵。':'暂未收录可确认的后续对阵，可前往 HLTV 查看。'):'暂未收录这支战队的近期赛果。'));}
    items.slice(0,20).forEach(match=>{
      const row=el('a','match-row');row.href=match.url;row.target='_blank';row.rel='noopener noreferrer';
      const result=active==='results';
      const oldObservation=age(match.observedAt||group.checkedAt)>35*60*1000;
      let badge=result?'已结束':match.status==='live'&&!oldObservation&&!localFile&&!staticArchive?'进行中':match.status==='postponed'?'延期':match.status==='live'||(validTime(match.startsAt)&&Date.parse(match.startsAt)<Date.now()-15*60*1000)?'待核实':'即将开赛';
      if(match.status==='forfeit')badge='判罚结果';if(match.status==='cancelled')badge='取消';
      const timing=el('div','match-timing');timing.append(el('span','match-status '+(badge==='进行中'?'is-live':''),badge),el('time','match-date',match.startsAt?date(match.startsAt):match.sourceDate?`${match.sourceDate.slice(5)} · 来源日期`:'时间待确认'));row.append(timing);
      const versus=el('div','match-versus');versus.append(teamElement(match.team1,cnIds));
      const score=el('strong','match-score',result?`${match.score1} : ${match.score2}`:'VS');versus.append(score,teamElement(match.team2,cnIds));row.append(versus);
      const detail=el('div','match-detail');detail.append(el('span','match-event-name',match.event),el('span','match-format',match.format==='unknown'?'赛制待确认':match.format.toUpperCase()));row.append(detail);
      if(result){let mark='CN 内战';const target=selected==='all'?(cnIds.has(match.team1.id)?match.team1.id:match.team2.id):Number(selected);if(!(selected==='all'&&cnIds.has(match.team1.id)&&cnIds.has(match.team2.id))){const own=target===match.team1.id?match.score1:match.score2,opp=target===match.team1.id?match.score2:match.score1;mark=own>opp?'胜':own<opp?'负':'平';}row.append(el('span','result-mark '+(mark==='胜'?'is-win':mark==='负'?'is-loss':''),mark));}else row.append(el('span','match-open','＋'));
      row.setAttribute('aria-label',`${match.team1.name} ${result?`${match.score1} 比 ${match.score2}`:'对阵'} ${match.team2.name}，${badge}，${date(match.startsAt)}，在 HLTV 打开`);
      list.append(row);
    });
    document.getElementById('feed-summary').textContent=`${active==='results'?'已收录赛果':'已收录对阵'} ${items.length} 场${items.length>20?' · 展示最近 20 场':''} · ${selected==='all'?'按 HLTV 中国旗战队筛选':filter.selectedOptions[0].textContent}${active==='results'?' · 比分为整场赛果':''}`;
    document.getElementById('feed-source-link').href=active==='upcoming'?'https://www.hltv.org/matches':'https://www.hltv.org/results';
    const enabled=data.updater?.enabled;
    if(staticArchive&&apiLink)apiLink.textContent='赛事存档 JSON ↗';
    document.getElementById('feed-cadence').textContent=localFile?'当前为本地离线存档，日期为原核验时间。打开在线版可读取服务器的最新存档。':staticArchive?'当前为静态发布的核验存档，自动采集未启用。刷新只读取已发布的 JSON，不会从 HLTV 采集新数据；页面每 60 秒检查更新，核验时间保留原日期。':`${enabled?`后台每 ${data.updater.intervalMinutes} 分钟核对 HLTV；`:'后台定时更新尚未确认启用；'}页面每 60 秒读取最新存档。显示采集时状态，不是逐回合直播比分。`;
  }
  function validFeed(next) {
    return !!next&&Array.isArray(next.teams)&&next.teams.every(t=>t&&Number.isInteger(t.id)&&typeof t.name==='string')&&['upcoming','results'].every(key=>next[key]&&Array.isArray(next[key].matches)&&next[key].matches.every(m=>m&&m.team1&&m.team2&&typeof m.team1.name==='string'&&typeof m.team2.name==='string'&&typeof m.url==='string'&&m.url.startsWith('https://www.hltv.org/matches/')&&typeof m.event==='string'&&typeof m.format==='string'));
  }
  function accept(next) {
    if(!validFeed(next))throw new Error('Invalid feed');
    const value=filter.value;data=next;
    filter.replaceChildren(new Option('全部中国战队','all'));
    next.teams.forEach(team=>filter.add(new Option(team.name,String(team.id))));
    if([...filter.options].some(o=>o.value===value))filter.value=value;
  }
  try {accept(JSON.parse(document.getElementById('initial-feed')?.textContent||'null'));draw();}catch{}
  async function load() {
    if(localFile){if(data)draw();return;}
    if(loading)return;loading=true;refresh.disabled=true;refresh.classList.add('refreshing');
    try {const response=await fetch(feedUrl,{cache:'no-store',signal:AbortSignal.timeout(12000)});if(!response.ok)throw new Error('load failed');accept(await response.json());requestError=false;draw();}
    catch {requestError=true;if(data)draw();else{list.replaceChildren(el('div','feed-empty','暂时无法读取赛事数据，请稍后重试或前往 HLTV。'));status.textContent='读取失败';status.classList.add('is-stale');list.setAttribute('aria-busy','false');}}
    finally{loading=false;refresh.disabled=false;refresh.classList.remove('refreshing');}
  }
  function selectTab(index,focus=false){active=tabs[index].dataset.feed;tabs.forEach((tab,i)=>{tab.setAttribute('aria-selected',String(i===index));tab.tabIndex=i===index?0:-1;});list.setAttribute('aria-labelledby',tabs[index].id);if(focus)tabs[index].focus();draw();}
  tabs.forEach((tab,index)=>{tab.addEventListener('click',()=>selectTab(index));tab.addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();selectTab(event.key==='Home'?0:event.key==='End'?1:1-index,true);}});});
  if(localFile){refresh.textContent='打开在线版 ↗';refresh.setAttribute('aria-label','打开在线赛事与战绩');}
  filter.addEventListener('change',draw);refresh.addEventListener('click',()=>{if(localFile)location.href=onlineUrl;else load();});document.addEventListener('visibilitychange',()=>{if(!document.hidden)load();});setInterval(()=>{if(!document.hidden)load();},60000);load();
})();
