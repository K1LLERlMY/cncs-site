/* Reading states follow the existing document; no pinned scenes or scroll control. */
(() => {
  'use strict';

  function initializeHistoryEffects() {
    const history = document.getElementById('history');
    if (!history || history.classList.contains('history-cinematic')) return;

    const selector = history.querySelector('.era-selector');
    const panelElements = [...history.querySelectorAll('.era-panel')];
    if (!selector || !panelElements.length) return;

    const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
    const compactScreen = matchMedia('(max-width: 700px), (pointer: coarse)');
    const navigation = [...selector.querySelectorAll('[data-era]')];
    const momentLookup = new WeakMap();
    const clamp = value => Math.max(0, Math.min(1, value));
    const pad = value => String(value).padStart(2, '0');
    let frame = 0;
    let nearHistory = !('IntersectionObserver' in window);
    let focusedMoment = null;

    function makeElement(tag, className) {
      const element = document.createElement(tag);
      element.className = className;
      return element;
    }

    function cancelDigits(panel) {
      panel.animations.splice(0).forEach(animation => animation.cancel());
    }

    const panels = panelElements.map((element, panelIndex) => {
      const key = element.dataset.eraKey || String(panelIndex);
      const moments = [...element.querySelectorAll('.milestone')].map((article, index) => {
        const baseId = `moment-${key.replace(/[^a-z0-9_-]/gi, '-')}-${index}`;
        let id = baseId, suffix = 1;
        while (document.getElementById(id) && document.getElementById(id) !== article) id = `${baseId}-${suffix++}`;
        article.id = id;
        article.dataset.momentIndex = String(index);
        const date = article.querySelector('.milestone-date > span')?.textContent || '';
        const year = date.match(/\d{4}/)?.[0] || '';
        const caption = article.querySelector('h4')?.textContent.trim() || '';
        momentLookup.set(article, { panelIndex, index });
        return { element: article, year, caption, read: '' };
      });

      const readout = makeElement('div', 'era-live-readout');
      readout.setAttribute('aria-hidden', 'true');
      const yearWindow = makeElement('div', 'era-year-window');
      const digits = Array.from({ length: 4 }, () => makeElement('span', 'era-year-digit'));
      yearWindow.append(...digits);
      const meta = makeElement('div', 'era-reading-meta');
      const indexLabel = makeElement('span', 'era-current-index');
      const captionLabel = makeElement('span', 'era-current-caption');
      meta.append(indexLabel, captionLabel);
      const segments = makeElement('div', 'era-segments');
      const markers = moments.map(() => document.createElement('i'));
      segments.append(...markers);
      readout.append(yearWindow, meta, segments);
      const intro = element.querySelector('.era-intro');
      const count = intro?.querySelector('.era-record-count');
      if (count) count.after(readout);
      else intro?.append(readout);

      // Move only the image: its original caption, links and gallery button stay put.
      element.querySelectorAll('.milestone-photo').forEach(figure => {
        const image = figure.querySelector(':scope > img');
        if (!image) return;
        const window = makeElement('div', 'moment-photo-window');
        image.before(window);
        window.append(image);
      });

      return {
        element, key, moments, digits, indexLabel, captionLabel, markers,
        activeIndex: -1, year: null, scene: '', animations: []
      };
    });

    const tabs = navigation.map(element => ({
      element,
      panelIndex: panels.findIndex(panel => panel.key === element.dataset.era),
      progress: ''
    }));

    function updateYear(panel, year, animate) {
      if (panel.year === year) return;
      cancelDigits(panel);
      const previousYear = panel.year;
      panel.year = year;
      panel.digits.forEach((digit, index) => { digit.textContent = year[index] || ''; });
      if (!animate || previousYear === null || reducedMotion.matches || compactScreen.matches || document.hidden) return;
      const direction = Number(year) < Number(previousYear) ? -1 : 1;
      panel.digits.forEach((digit, index) => {
        if (typeof digit.animate !== 'function') return;
        const animation = digit.animate([
          { transform: `translateY(${direction * 65}%)`, opacity: 0 },
          { transform: 'translateY(0)', opacity: 1 }
        ], { duration: 360, delay: index * 22, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'backwards' });
        panel.animations.push(animation);
        animation.finished.then(() => {
          const position = panel.animations.indexOf(animation);
          if (position !== -1) panel.animations.splice(position, 1);
          animation.cancel();
        }).catch(() => {});
      });
    }

    function updateReadout(panel, index, animate) {
      if (panel.activeIndex === index || !panel.moments[index]) return;
      panel.activeIndex = index;
      const moment = panel.moments[index];
      panel.indexLabel.textContent = `${pad(index + 1)} / ${pad(panel.moments.length)}`;
      panel.captionLabel.textContent = moment.caption;
      panel.moments.forEach((item, itemIndex) => {
        item.element.classList.toggle('is-moment-current', itemIndex === index);
        item.element.classList.toggle('is-moment-past', itemIndex < index);
        panel.markers[itemIndex].classList.toggle('is-read', itemIndex <= index);
      });
      updateYear(panel, moment.year, animate);
    }

    function update() {
      frame = 0;
      if (document.hidden) return;

      // Complete every geometry read before changing classes, text or inline styles.
      const viewportHeight = innerHeight;
      const selectorBox = selector.getBoundingClientRect();
      const panelBoxes = panels.map(panel => panel.element.getBoundingClientRect());
      const momentBoxes = panels.map(panel => panel.moments.map(moment => moment.element.getBoundingClientRect()));
      // Keep the active era identical to app.js, independent of either RAF's order.
      const eraLine = Math.max(selectorBox.bottom + 30, viewportHeight * .28);
      const momentLine = Math.max(selectorBox.bottom + 60, viewportHeight * .45);
      let activePanel = panelBoxes.findIndex(box => box.bottom > eraLine);
      if (activePanel === -1) activePanel = panels.length - 1;

      const states = panels.map((panel, panelIndex) => {
        const box = panelBoxes[panelIndex];
        let index = 0;
        momentBoxes[panelIndex].forEach((momentBox, itemIndex) => {
          if (momentBox.top <= momentLine) index = itemIndex;
        });
        if (focusedMoment?.panelIndex === panelIndex) index = focusedMoment.index;
        return {
          index,
          scene: clamp((momentLine - box.top) / Math.max(1, box.height)).toFixed(3),
          progress: panelIndex < activePanel ? '1.000' : panelIndex > activePanel ? '0.000' :
            clamp((eraLine - box.top) / Math.max(1, box.height)).toFixed(3),
          reads: momentBoxes[panelIndex].map((momentBox, itemIndex) => itemIndex < index ? '1.000' : itemIndex > index ? '0.000' :
            clamp((momentLine - momentBox.top) / Math.max(1, momentBox.height)).toFixed(3))
        };
      });

      panels.forEach((panel, panelIndex) => {
        const state = states[panelIndex];
        panel.element.classList.toggle('is-era-current', panelIndex === activePanel);
        updateReadout(panel, state.index, nearHistory && panelIndex === activePanel);
        if (panel.scene !== state.scene) {
          panel.scene = state.scene;
          panel.element.style.setProperty('--era-scene-progress', state.scene);
        }
        panel.moments.forEach((moment, index) => {
          if (moment.read === state.reads[index]) return;
          moment.read = state.reads[index];
          moment.element.style.setProperty('--moment-read', moment.read);
        });
      });
      tabs.forEach(tab => {
        if (tab.panelIndex < 0) return;
        const progress = states[tab.panelIndex].progress;
        if (tab.progress === progress) return;
        tab.progress = progress;
        tab.element.style.setProperty('--era-tab-progress', progress);
      });
    }

    function schedule(force = false) {
      if (frame || document.hidden || (!force && !nearHistory)) return;
      frame = requestAnimationFrame(update);
    }

    history.classList.add('history-cinematic');
    addEventListener('scroll', () => {
      focusedMoment = null;
      schedule();
    }, { passive: true });
    addEventListener('resize', () => schedule(), { passive: true });
    history.addEventListener('load', () => schedule(), true);
    history.addEventListener('focusin', event => {
      const article = event.target.closest?.('.milestone');
      const moment = article && momentLookup.get(article);
      if (!moment) return;
      focusedMoment = moment;
      schedule(true);
    });

    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(entries => {
        nearHistory = entries.some(entry => entry.isIntersecting);
        if (!nearHistory) panels.forEach(cancelDigits);
        // One final boundary update gives all completed/future tabs their end states.
        schedule(true);
      }, { rootMargin: '600px 0px 600px 0px', threshold: 0 });
      observer.observe(history);
    }
    if ('ResizeObserver' in window) {
      const observer = new ResizeObserver(() => schedule());
      panels.forEach(panel => observer.observe(panel.element));
      observer.observe(selector);
    }
    const motionChanged = () => {
      panels.forEach(cancelDigits);
      schedule();
    };
    reducedMotion.addEventListener('change', motionChanged);
    compactScreen.addEventListener('change', motionChanged);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        if (frame) cancelAnimationFrame(frame);
        frame = 0;
        panels.forEach(cancelDigits);
      } else schedule(true);
    });
    document.fonts?.ready.then(() => schedule());
    schedule(true);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initializeHistoryEffects, { once: true });
  else initializeHistoryEffects();
})();
