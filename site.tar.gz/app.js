'use strict';

const eras = {
  classic: {
    chapter: '01', image: 'assets/logos/wnv.webp', imageAlt: 'wNv Teamwork 队标', caption: 'wNv / THE PIONEERS',
    eyebrow: '2000s / THE FIRST CHAPTER', mark: '1.6', title: '从网吧走向世界。',
    description: 'CRT 显示器、局域网、熟悉的 Dust2。中国 CS 的故事，在一次次组队与世界大赛的交汇中，留下了最初的名字。',
    milestones: [
      { date: '2005.12', title: 'wNv，让世界记住中国 CS。', body: '在北京举行的 WEG 2005 第三赛季决赛，wNv 以 2:1 击败 project_kr，捧起冠军奖杯。属于中国 CS 的早期荣光，成为一代玩家共同的记忆。', label: 'WEG 2005 SEASON 3 · 冠军', url: 'https://www.csgo.com.cn/article/details/20180605/211571.html' },
      { date: '2006.05', title: '再一次，站上最高处。', body: '杭州，WEG Masters 2006。wNv 在决赛以 2:0 战胜 compLexity，再夺 WEG 系列赛事冠军。一次突破之后，他们用第二座奖杯回答期待。', label: 'WEG MASTERS 2006 · 冠军', url: 'https://www.hltv.org/news/139/wnv-takes-out-weg-masters' }
    ]
  },
  csgo: {
    chapter: '02', image: 'assets/logos/tyloo-20261009.webp', imageAlt: 'TYLOO 当前队标', caption: 'TYLOO / AGAINST THE ODDS',
    eyebrow: '2010s / AGAINST THE ODDS', mark: 'GO', title: '把名字留在世界赛场。',
    description: '新的版本，新的对手。中国 CS 经历磨合与低谷，也在一次次出征里，用真正打出来的回合，为自己争取位置。',
    milestones: [
      { date: '2016.04', title: '马尔默，一场不被看好的胜利。', body: 'TYLOO 在 DreamHack Masters Malmö 以 2:1 淘汰刚刚获得 Major 冠军的 Luminosity，晋级八强。世界开始重新看待这支中国队。', label: 'DREAMHACK MASTERS MALMÖ · 八强', url: 'https://www.hltv.org/news/17557/tyloo-stun-luminosity-in-malm' },
      { date: '2017.09', title: '国服开启，更多人走进赛场。', body: '9 月 15 日，由完美世界运营的 CS:GO 国服正式公测。从老玩家到新面孔，一句熟悉的「一起打吗」，有了更多回应。', label: 'CS:GO 国服 · 正式公测', url: 'https://www.csgo.com.cn/news/gamebroad/20170915/206297.shtml' },
      { date: '2018.05', title: '悉尼四强，更进一步。', body: 'TYLOO 闯入 IEM Sydney 半决赛，最终位列第 3–4 名。面对世界强队，中国 CS 正在争取更大的舞台。', label: 'IEM SYDNEY 2018 · 四强', url: 'https://www.hltv.org/events/3530/iem-sydney-2018' },
      { date: '2018.09', title: '伦敦，走进 Major 十六强。', body: 'TYLOO 以 2:0 击败 Spirit，以 3 胜 2 负从 FACEIT Major 挑战者阶段出线，进入新传奇阶段。这个十六强，成为后来者追赶的坐标。', label: 'FACEIT MAJOR LONDON · 十六强', url: 'https://www.hltv.org/news/24715/tyloo-to-new-legends-stage-over-spirit' }
    ]
  },
  cs2: {
    chapter: '03', image: 'assets/tyloo-fissure-2025-poster.webp', imageAlt: 'TYLOO 在 2025 FISSURE Playground 1 夺冠后举杯', caption: 'BELGRADE / THE NEXT CHAPTER',
    eyebrow: '2023 — NOW / THE STORY CONTINUES', mark: 'CS2', title: '新的篇章，属于每一个我们。',
    description: '从重返 Major，到在中国主场相遇，再到海外捧杯。CS2 时代的中国 CS，正在写下属于这一代的新答案。',
    milestones: [
      { date: '2024.02', title: 'Lynn Vision，第一次登上 Major。', body: 'LVG 以 2:1 战胜 Grayhound，拿到哥本哈根 Major 入场券。这是队史首次晋级 Major，也是中国战队自 2021 年以来重返这一舞台。', label: 'PGL MAJOR COPENHAGEN · 首次晋级', url: 'https://www.hltv.org/news/38364/lynn-vision-qualify-for-the-major-over-grayhound' },
      { date: '2024.11—12', title: '上海，世界走进我们的主场。', body: '11 月 30 日至 12 月 15 日，24 支战队相聚上海。Major 第一次落地亚洲、来到中国，让无数玩家等到了家门口的世界大赛。', label: 'PERFECT WORLD SHANGHAI MAJOR', url: 'https://www.csgo.com.cn/article/details/20241108/225770.html' },
      { date: '2024.12', title: 'Rare Atom，把胜利留在主场。', body: 'RA 在上海 Major 以 2:1 击败 fnatic。这是中国队自 2018 年以来再次赢下 Major 的 BO3，也让中国主场的欢呼有了自己的名字。', label: 'SHANGHAI MAJOR · RA 2:1 FNATIC', url: 'https://www.hltv.org/news/40436/rare-atom-eliminate-fnatic-from-shanghai-major' },
      { date: '2025.06', title: '七年之后，重返十六强。', body: 'LVG 以 2:1 战胜 B8，晋级奥斯汀 Major 第三阶段。时隔七年，中国战队再次进入 Major 十六强，最终获得第 12–14 名。', label: 'BLAST.TV AUSTIN MAJOR · 十六强', url: 'https://www.hltv.org/news/41922/lynn-vision-to-austin-major-stage-3-over-b8' },
      { date: '2025.07', title: '天禄捧杯，新的里程碑。', body: 'FISSURE Playground 1 决赛，TYLOO 以 3:1 战胜 Astralis，赢得队史首个亚洲以外的线下赛事冠军。JamYoung 成为首位获得 HLTV MVP 奖章的中国选手。', label: 'FISSURE PLAYGROUND 1 · 冠军', url: 'https://www.hltv.org/news/42243/jamyoung-powers-tyloo-to-fissure-playground-1-victory' },
      { date: '2026.05', title: 'LVG，续写亚洲赛场的新章。', body: 'Lynn Vision 在上海举行的 ACL 2026 总决赛以 3:1 击败 JiJieHao，夺得冠军并获得 Esports World Cup 2026 参赛资格。下一程，继续出发。', label: 'HERO ESPORTS ACL 2026 · 冠军', url: 'https://www.hltv.org/matches/2394271/jijiehao-vs-lynn-vision-hero-esports-asian-champions-league-2026' }
    ]
  }
};

const teamStories = {
  wnv: { name: 'wNv', era: 'CS 1.6 / THE PIONEERS', description: '提起中国 CS 的早期荣光，wNv 是无法绕开的名字。在 1.6 的年代，他们让中国队站上国际赛事的领奖台，也让很多人第一次相信，我们可以赢。', moment: '2005 → 2006 · 两座 WEG 奖杯', detail: '从 WEG 2005 第三赛季冠军，到 WEG Masters 2006 冠军。时代已经翻页，那些名字和比赛，仍是中国 CS 记忆的一部分。', url: 'https://www.hltv.org/news/139/wnv-takes-out-weg-masters' },
  tyloo: { name: 'TYLOO', era: '跨越世代 / THE PERSISTENCE', description: '天禄，是几代中国 CS 玩家熟悉的名字。从马尔默的惊喜、伦敦的突破，到 CS2 时代的海外捧杯，这支队伍的故事里，有等待，也有再出发。', moment: '2025 · 贝尔格莱德捧杯', detail: 'TYLOO 在 FISSURE Playground 1 决赛以 3:1 击败 Astralis。JamYoung 获得 HLTV MVP，成为首位获此奖章的中国选手。', url: 'https://www.hltv.org/news/42243/jamyoung-powers-tyloo-to-fissure-playground-1-victory' },
  lvg: { name: 'LYNN VISION', era: 'CS:GO → CS2 / THE NEW WAVE', description: '从第一次拿到 Major 门票，到重返十六强，Lynn Vision 把一个个目标变成了真实的赛果。新的面孔，也在接过前人的期待。', moment: '2025 · 奥斯汀 Major 十六强', detail: 'LVG 以 2:1 击败 B8，闯入奥斯汀 Major 第三阶段。中国战队在七年之后，再次走进 Major 十六强。2026 年，他们又拿下 ACL 冠军。', url: 'https://www.hltv.org/news/41922/lynn-vision-to-austin-major-stage-3-over-b8' },
  ra: { name: 'RARE ATOM', era: 'CS:GO → CS2 / THE HOME CROWD', description: '在第一次于中国举办的 Major 上，Rare Atom 承载着主场的目光。从 RMR 突围到站上上海赛场，他们让看台上的呐喊，有了最直接的回应。', moment: '2024 · 上海，主场的一场胜利', detail: 'RA 在上海 Major 以 2:1 击败 fnatic，拿下中国队自 2018 年以来首场 Major BO3 胜利。对于现场观众，这是一段可以一起回想的记忆。', url: 'https://www.hltv.org/news/40436/rare-atom-eliminate-fnatic-from-shanghai-major' }
};

const eraLinks = [...document.querySelectorAll('[data-era]')];
const interactionMotion = matchMedia('(prefers-reduced-motion: reduce)');
const interactionEase = 'cubic-bezier(.22,1,.36,1)';
const canAnimate = () => !interactionMotion.matches && typeof Element.prototype.animate === 'function';
function animateInteraction(element, frames, timing, animations) {
  const animation = element.animate(frames, { easing: interactionEase, fill: 'both', ...timing });
  animations.push(animation);
  return animation.finished.catch(() => {});
}
function cancelInteractions(animations) { animations.splice(0).forEach(animation => animation.cancel()); }

// Every era is in the document: scrolling reads the full history, links only jump.
const eraTemplate = document.getElementById('era-panel');
const initialEraHash = location.hash;
const historyMedia = window.CNCS_HISTORY_MEDIA || { covers: {}, moments: {} };
const eraChapters = document.createElement('div');
eraChapters.className = 'era-chapters';
const eraPanels = Object.entries(eras).map(([key, era]) => {
  const panel = eraTemplate.cloneNode(true);
  panel.id = `era-${key}`;
  panel.setAttribute('role', 'region');
  panel.setAttribute('tabindex', '-1');
  panel.setAttribute('aria-labelledby', `era-title-${key}`);
  panel.dataset.eraKey = key;
  const part = id => panel.querySelector(`#${id}`);
  part('era-title').textContent = era.title;
  part('era-description').textContent = era.description;
  part('era-mark').textContent = era.mark;
  part('era-chapter').textContent = `CHAPTER ${era.chapter}`;
  part('era-image').src = era.image;
  part('era-image').alt = era.imageAlt;
  part('era-caption').textContent = era.caption;
  const cover = historyMedia.covers?.[key];
  if (cover) {
    panel.querySelector('.era-art').classList.add('has-photo');
    part('era-image').src = cover.file;
    part('era-image').alt = cover.alt;
    part('era-image').style.objectPosition = cover.objectPosition || 'center';
    part('era-caption').textContent = `${cover.caption} · `;
    const source = document.createElement('a'); source.href = cover.sourcePage; source.target = '_blank'; source.rel = 'noopener noreferrer'; source.textContent = '图源 ↗'; source.title = cover.credit || '原始图片报道';
    part('era-caption').append(source);
  }
  part('era-count').textContent = String(era.milestones.length).padStart(2, '0');
  panel.querySelector('.era-index').textContent = era.eyebrow;
  part('milestones').replaceChildren(...era.milestones.map((item, index) => {
    const article = document.createElement('article');
    article.className = 'milestone';
    const date = document.createElement('div'); date.className = 'milestone-date';
    const year = document.createElement('span'); year.textContent = item.date.split('.')[0];
    const month = document.createElement('small'); month.textContent = `/${item.date.split('.')[1]}`;
    date.append(year, month);
    const number = document.createElement('span'); number.className = 'milestone-number'; number.textContent = `${String(index + 1).padStart(2, '0')} / ${String(era.milestones.length).padStart(2, '0')}`; number.setAttribute('aria-hidden', 'true');
    const title = document.createElement('h4'); title.textContent = item.title;
    const body = document.createElement('p'); body.textContent = item.body;
    const bottom = document.createElement('div'); bottom.className = 'milestone-bottom';
    const label = document.createElement('span'); label.textContent = item.label;
    const link = document.createElement('a'); link.href = item.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = '赛事档案 ↗'; link.setAttribute('aria-label', `${item.title} 赛事档案，在新标签页打开`);
    bottom.append(label, link); article.append(number, date, title);
    const photo = historyMedia.moments?.[key]?.[item.date];
    if (photo) {
      const figure = document.createElement('figure'); figure.className = 'milestone-photo';
      if (photo.width <= 400) figure.classList.add('compact-photo');
      const image = document.createElement('img'); image.src = photo.file; image.alt = photo.alt; image.loading = 'lazy'; image.decoding = 'async'; image.width = photo.width || 960; image.height = photo.height || 540;
      image.style.aspectRatio = `${image.width} / ${image.height}`;
      const caption = document.createElement('figcaption');
      const text = document.createElement('span'); text.textContent = photo.caption;
      const source = document.createElement('a'); source.href = photo.sourcePage; source.target = '_blank'; source.rel = 'noopener noreferrer'; source.textContent = '图片来源 ↗'; source.title = photo.credit || '原始图片报道';
      caption.append(text, source); figure.append(image, caption); article.append(figure);
    }
    article.append(body, bottom); return article;
  }));
  panel.querySelectorAll('[id]').forEach(element => { element.id += `-${key}`; });
  eraChapters.append(panel);
  return panel;
});
eraTemplate.replaceWith(eraChapters);
const eraSelector = document.querySelector('.era-selector');
const historySection = document.getElementById('history');
let eraScrollFrame = 0, currentEra = '';
function updateEraPosition() {
  eraScrollFrame = 0;
  const selectorBox = eraSelector.getBoundingClientRect();
  const line = Math.max(selectorBox.bottom + 30, innerHeight * .28);
  const withinHistory = historySection.getBoundingClientRect();
  const active = eraPanels.find(panel => panel.getBoundingClientRect().bottom > line) || eraPanels.at(-1);
  const key = active.dataset.eraKey;
  if (key !== currentEra) {
    currentEra = key;
    eraLinks.forEach(link => {
      if (link.dataset.era === key) link.setAttribute('aria-current', 'true');
      else link.removeAttribute('aria-current');
    });
    eraSelector.style.setProperty('--era-active', eraPanels.indexOf(active));
  }
  eraSelector.classList.toggle('is-pinned', selectorBox.top <= 101 && withinHistory.top < 0 && withinHistory.bottom > selectorBox.height);
}
function scheduleEraPosition() {
  if (!eraScrollFrame) eraScrollFrame = requestAnimationFrame(updateEraPosition);
}
function fitEraCovers() {
  const covers = eraPanels.map(panel => panel.querySelector('.era-intro'));
  const tooTall = covers.map(cover => cover.scrollHeight > innerHeight - 240);
  covers.forEach((cover, index) => cover.classList.toggle('is-flowing', tooTall[index]));
  scheduleEraPosition();
}
addEventListener('scroll', scheduleEraPosition, { passive: true });
addEventListener('resize', fitEraCovers, { passive: true });
document.fonts?.ready.then(fitEraCovers);
if ('ResizeObserver' in window) new ResizeObserver(scheduleEraPosition).observe(historySection);
fitEraCovers();
// Wait for the other defer scripts and fonts before restoring a dynamic fragment.
const initialChapter = eraPanels.find(panel => `#${panel.id}` === initialEraHash);
if (initialChapter) {
  let userNavigated = false;
  const cancelInitialJump = () => { userNavigated = true; };
  const inputs = ['wheel', 'touchstart', 'keydown'];
  inputs.forEach(type => addEventListener(type, cancelInitialJump, { once: true, passive: true }));
  const restoreInitialChapter = () => Promise.resolve(document.fonts?.ready).then(() => requestAnimationFrame(() => requestAnimationFrame(() => {
    inputs.forEach(type => removeEventListener(type, cancelInitialJump));
    if (!userNavigated && location.hash === initialEraHash && scrollY === 0) initialChapter.scrollIntoView({ behavior: 'instant', block: 'start' });
  })));
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', restoreInitialChapter, { once: true });
  else restoreInitialChapter();
}

// Real timeline items reveal when reached; reduced-motion keeps them static.
if ('IntersectionObserver' in window && !interactionMotion.matches) {
  const timelineObserver = new IntersectionObserver(entries => entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    entry.target.classList.add('timeline-visible');
    timelineObserver.unobserve(entry.target);
  }), { threshold: .04, rootMargin: '0px 0px -20px 0px' });
  eraPanels.forEach(panel => {
    panel.querySelectorAll('.era-art, .milestone').forEach(element => {
      element.classList.add('timeline-reveal'); timelineObserver.observe(element);
    });
  });
}

const menu = document.getElementById('chapter-menu');
const menuButton = document.querySelector('.menu-button');
const teamDialog = document.getElementById('team-dialog');
const dialogs = [menu, teamDialog];
const dialogStates = new WeakMap();
const menuDepth = document.createElement('div');
menuDepth.className = 'menu-depth'; menuDepth.setAttribute('aria-hidden', 'true');
for (let index = 0; index < 3; index++) menuDepth.append(document.createElement('span'));
menu.prepend(menuDepth);
menu.querySelectorAll('nav a').forEach((link, index) => {
  link.classList.add('chapter-link'); link.style.setProperty('--chapter-order', index);
  [...link.childNodes].filter(node => node.nodeType === Node.TEXT_NODE && node.textContent.trim()).forEach(node => {
    const label = document.createElement('span'); label.className = 'chapter-label';
    label.textContent = node.textContent; node.replaceWith(label);
  });
});
function getDialogState(dialog) {
  if (!dialogStates.has(dialog)) dialogStates.set(dialog, { run: 0, animations: [], trigger: null, closing: null });
  return dialogStates.get(dialog);
}
function syncDialogChrome() {
  document.body.classList.toggle('dialog-open', dialogs.some(dialog => dialog.open));
  menuButton.setAttribute('aria-expanded', String(menu.open));
}
function dialogParts(dialog) {
  return dialog === menu
    ? [...dialog.querySelectorAll('.dialog-top, nav a, :scope > p')]
    : [...dialog.querySelectorAll('.dialog-top, .team-dialog-kicker, h2, #team-dialog-description, .team-dialog-fact, .pill-link')];
}
function frameOf(element, properties = ['opacity', 'transform', 'filter']) {
  const style = getComputedStyle(element);
  return Object.fromEntries(properties.map(property => [property, style[property]]));
}
async function openDialog(dialog) {
  const state = getDialogState(dialog);
  if (dialog.open && dialog.dataset.dialogPhase !== 'closing') return;
  const interrupted = dialog.open;
  const parts = dialogParts(dialog);
  const currentRoot = interrupted ? frameOf(dialog, ['opacity', 'transform', 'clipPath']) : null;
  const currentParts = interrupted ? parts.map(element => frameOf(element)) : [];
  const curtains = dialog === menu ? [...menuDepth.children] : [];
  const currentCurtains = interrupted ? curtains.map(element => frameOf(element, ['transform'])) : [];
  const run = ++state.run;
  cancelInteractions(state.animations);
  state.closing = null;
  dialog.classList.add('interaction-dialog');
  if (!dialog.open) {
    state.trigger = document.activeElement;
    dialog.showModal();
    dialog.scrollTop = 0;
  }
  syncDialogChrome();
  if (!canAnimate()) { dialog.dataset.dialogPhase = 'open'; return; }
  dialog.dataset.dialogPhase = 'opening';
  const work = [];
  if (dialog === menu) {
    // The native dialog focuses Close immediately; keep its toolbar unmasked.
    const toolbar = dialog.querySelector('.dialog-top');
    const visibleTop = Math.min(dialog.clientHeight, toolbar.offsetTop + toolbar.offsetHeight + 12);
    work.push(animateInteraction(dialog, [
      currentRoot || { opacity: 1, transform: 'none', clipPath: `inset(0 0 calc(100% - ${visibleTop}px) 0)` },
      { opacity: 1, transform: 'none', clipPath: 'inset(0 0 0% 0)' }
    ], { duration: interrupted ? 440 : 640 }, state.animations));
    curtains.forEach((element, index) => work.push(animateInteraction(element, [
      currentCurtains[index] || { transform: 'translateY(0%)' }, { transform: 'translateY(-110%)' }
    ], { duration: 580, delay: 40 + index * 60 }, state.animations)));
  } else {
    work.push(animateInteraction(dialog, [
      currentRoot || { opacity: 1, transform: 'translateY(64px) scale(.94)', clipPath: 'inset(0% 0 0% 0)' },
      { opacity: 1, transform: 'translateY(0) scale(1)', clipPath: 'inset(0% 0 0% 0)' }
    ], { duration: 660 }, state.animations));
  }
  parts.forEach((element, index) => {
    if (element.classList.contains('dialog-top')) return;
    const finalOpacity = getComputedStyle(element).opacity;
    work.push(animateInteraction(element, [
      currentParts[index] || { opacity: 0, transform: dialog === menu ? 'translateY(48px)' : 'translateY(24px)', filter: 'blur(5px)' },
      { opacity: finalOpacity, transform: 'translateY(0)', filter: 'blur(0px)' }
    ], {
      duration: dialog === menu ? 540 : 560,
      delay: dialog === menu ? (interrupted ? 0 : 70) + (index - 1) * 35 : (interrupted ? 0 : 150) + index * 65
    }, state.animations));
  });
  await Promise.all(work);
  if (state.run !== run || !dialog.open) return;
  cancelInteractions(state.animations); dialog.dataset.dialogPhase = 'open';
}
function closeDialog(dialog) {
  const state = getDialogState(dialog);
  if (!dialog.open) return Promise.resolve(false);
  if (state.closing) return state.closing;
  const parts = dialogParts(dialog);
  const currentRoot = frameOf(dialog, ['opacity', 'transform', 'clipPath']);
  const currentParts = parts.map(element => frameOf(element));
  const curtains = dialog === menu ? [...menuDepth.children] : [];
  const currentCurtains = curtains.map(element => frameOf(element, ['transform']));
  const run = ++state.run;
  cancelInteractions(state.animations);
  dialog.dataset.dialogPhase = 'closing';
  const work = [];
  if (canAnimate()) {
    work.push(animateInteraction(dialog, [currentRoot, dialog === menu
      ? { opacity: 1, transform: 'none', clipPath: 'inset(0 0 100% 0)' }
      : { opacity: 0, transform: 'translateY(34px) scale(.97)', clipPath: 'inset(3% 0 3% 0)' }
    ], { duration: dialog === menu ? 580 : 330, delay: dialog === menu ? 80 : 0, easing: 'cubic-bezier(.55,0,.3,1)' }, state.animations));
    parts.forEach((element, index) => work.push(animateInteraction(element, [
      currentParts[index], { opacity: 0, transform: 'translateY(-18px)', filter: 'blur(3px)' }
    ], { duration: 220, delay: (parts.length - index - 1) * 22 }, state.animations)));
    curtains.forEach((element, index) => work.push(animateInteraction(element, [
      currentCurtains[index], { transform: 'translateY(0%)' }
    ], { duration: 440, delay: index * 45 }, state.animations)));
  }
  state.closing = Promise.all(work).then(() => {
    if (state.run !== run || !dialog.open) return false;
    cancelInteractions(state.animations);
    dialog.close(); syncDialogChrome();
    return true;
  });
  return state.closing;
}
menuButton.addEventListener('click', () => openDialog(menu));
dialogs.forEach(dialog => {
  dialog.querySelector('[data-close]').addEventListener('click', () => closeDialog(dialog));
  dialog.addEventListener('cancel', event => { event.preventDefault(); closeDialog(dialog); });
  dialog.addEventListener('focusin', event => {
    if (dialog.dataset.dialogPhase !== 'opening' || event.target.closest('.dialog-top')) return;
    // Tabbing into staggered content must reveal the new focus immediately.
    getDialogState(dialog).animations.forEach(animation => {
      try { animation.finish(); } catch { animation.cancel(); }
    });
  });
  dialog.addEventListener('close', () => {
    // A queued native close event must not cancel a dialog already reopened.
    if (dialog.open) return;
    const state = getDialogState(dialog);
    ++state.run; cancelInteractions(state.animations); state.closing = null;
    delete dialog.dataset.dialogPhase; syncDialogChrome();
    if (!dialogs.some(item => item.open) && state.trigger?.isConnected) state.trigger.focus({ preventScroll: true });
  });
  dialog.addEventListener('click', event => { if (event.target === dialog) { const box = dialog.getBoundingClientRect(); if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) closeDialog(dialog); } });
});
menu.querySelectorAll('nav a').forEach(link => link.addEventListener('click', async event => {
  if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  const destination = document.getElementById(link.hash.slice(1));
  if (!destination) return;
  event.preventDefault();
  if (!await closeDialog(menu)) return;
  getDialogState(menu).trigger = null;
  if (window.location.hash !== link.hash) history.pushState(null, '', link.hash);
  const temporaryFocus = !destination.hasAttribute('tabindex');
  if (temporaryFocus) destination.tabIndex = -1;
  destination.focus({ preventScroll: true });
  destination.scrollIntoView({ behavior: interactionMotion.matches ? 'auto' : 'smooth', block: 'start' });
  if (temporaryFocus) destination.addEventListener('blur', () => destination.removeAttribute('tabindex'), { once: true });
}));

interactionMotion.addEventListener('change', event => {
  if (!event.matches) return;
  dialogs.flatMap(dialog => getDialogState(dialog).animations).forEach(animation => {
    try { animation.finish(); } catch { animation.cancel(); }
  });
});
document.querySelectorAll('[data-team]').forEach(button => button.addEventListener('click', () => {
  const team = teamStories[button.dataset.team];
  document.getElementById('team-dialog-title').textContent = team.name;
  document.getElementById('team-dialog-era').textContent = team.era;
  document.getElementById('team-dialog-description').textContent = team.description;
  document.getElementById('team-dialog-moment').textContent = team.moment;
  document.getElementById('team-dialog-detail').textContent = team.detail;
  document.getElementById('team-dialog-source').href = team.url;
  openDialog(teamDialog);
}));

if ('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const observer = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); } }), { threshold: 0.08 });
  document.querySelectorAll('.section-heading, .spirit-grid, .team-grid, .next-grid').forEach(element => { element.classList.add('reveal'); observer.observe(element); });
}
