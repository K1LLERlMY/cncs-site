'use strict';
(() => {
  function enhanceArena() {
    const arena = document.querySelector('.arena');
    const stage = arena?.querySelector('.arena-stage');
    const title = arena?.querySelector('#arena-title');
    const next = document.querySelector('.next-chapter');
    if (!arena || !stage || !title || !next || arena.classList.contains('arena-effects')) return;

    // Keep the original heading/span and accessible wording. The new em layers
    // reveal text without replacing the transforms owned by motion.js.
    const firstText = [...title.childNodes].find(node => node.nodeType === Node.TEXT_NODE && node.textContent.trim());
    const secondLine = title.querySelector(':scope > span');
    if (firstText && secondLine) {
      const accessibleTitle = [...title.childNodes].map(node => node.nodeName === 'BR' ? ' ' : node.textContent).join('').replace(/\s+/g, ' ').trim();
      const first = document.createElement('em');
      first.className = 'arena-word-line arena-word-line--first';
      first.textContent = firstText.textContent;
      const second = document.createElement('em');
      second.className = 'arena-word-line arena-word-line--second';
      second.append(...secondLine.childNodes);
      firstText.replaceWith(first);
      secondLine.append(second);
      title.classList.add('arena-title-lines');
      if (!title.hasAttribute('aria-label')) title.setAttribute('aria-label', accessibleTitle);
    }

    const frame = document.createElement('div');
    frame.className = 'arena-camera-frame';
    frame.setAttribute('aria-hidden', 'true');
    const stamp = document.createElement('div');
    stamp.className = 'arena-city-stamp';
    stamp.setAttribute('aria-hidden', 'true');
    stamp.append(document.createTextNode('SHANGHAI'));
    const stampYear = document.createElement('small');
    stampYear.textContent = '2024 / 上海';
    stamp.append(stampYear);
    const meter = document.createElement('div');
    meter.className = 'arena-scene-meter';
    meter.setAttribute('aria-hidden', 'true');
    const meterStart = document.createElement('span');
    meterStart.textContent = '04 / OUR HOME';
    const track = document.createElement('div');
    track.className = 'arena-meter-track';
    track.append(document.createElement('i'));
    const meterEnd = document.createElement('span');
    meterEnd.textContent = '05 / NEXT';
    meter.append(meterStart, track, meterEnd);
    stage.append(frame, stamp, meter);

    const divider = document.createElement('div');
    divider.className = 'next-scene-divider';
    divider.setAttribute('aria-hidden', 'true');
    const round = document.createElement('span');
    round.textContent = 'NEXT ROUND / 05';
    divider.append(round);
    next.prepend(divider);
    arena.classList.add('arena-effects');
    next.classList.add('next-scene-effects');

    // Unsupported observers get the complete static view, with no scroll work.
    if (!('IntersectionObserver' in window)) return;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    const compact = matchMedia('(max-height: 520px), (max-width: 700px) and (max-height: 650px)');
    const forcedColours = matchMedia('(forced-colors: active)');
    const clamp = value => Math.max(0, Math.min(1, value));
    const previous = new WeakMap();
    let arenaNear = false, nextNear = false, motionAllowed = false, frameId = 0;
    function setVariable(element, name, value) {
      if (!previous.has(element)) previous.set(element, new Map());
      const values = previous.get(element);
      if (values.get(name) === value) return;
      values.set(name, value);
      element.style.setProperty(name, value);
    }
    function render() {
      frameId = 0;
      if (document.hidden || !motionAllowed) return;
      const height = innerHeight;
      // All geometry reads precede writes; sections outside the observer range
      // require neither measurements nor style updates.
      const arenaBox = arenaNear ? arena.getBoundingClientRect() : null;
      const nextBox = nextNear ? next.getBoundingClientRect() : null;
      if (arenaBox) {
        const entry = clamp((height - arenaBox.top) / (height * .85));
        const dwell = Math.max(arenaBox.height - height, 0);
        const progress = clamp((height * .78 - arenaBox.top) / Math.max(height * .78 + dwell, 1));
        setVariable(arena, '--arena-fx-colour', clamp((progress - .1) / .7).toFixed(3));
        setVariable(arena, '--arena-fx-first-cut', `${(100 * (1 - clamp((entry - .16) / .58))).toFixed(2)}%`);
        setVariable(arena, '--arena-fx-second-cut', `${(100 * (1 - clamp((entry - .38) / .56))).toFixed(2)}%`);
        setVariable(arena, '--arena-fx-progress', progress.toFixed(3));
        setVariable(arena, '--arena-fx-frame', (.35 + .4 * entry).toFixed(3));
      }
      if (nextBox) {
        const arrival = clamp((height * .96 - nextBox.top) / (height * .5));
        setVariable(next, '--next-fx-arrival', arrival.toFixed(3));
      }
    }
    function schedule() {
      if (!frameId && !document.hidden && motionAllowed && (arenaNear || nextNear)) frameId = requestAnimationFrame(render);
    }
    function updateMode() {
      if (document.hidden) return;
      motionAllowed = !reduced.matches && !compact.matches && !forcedColours.matches;
      arena.classList.toggle('arena-effects-live', motionAllowed);
      next.classList.toggle('next-effects-live', motionAllowed);
      if (!motionAllowed && frameId) { cancelAnimationFrame(frameId); frameId = 0; }
      schedule();
    }
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.target === arena) arenaNear = entry.isIntersecting;
        if (entry.target === next) nextNear = entry.isIntersecting;
      });
      schedule();
    }, { rootMargin: '160px 0px', threshold: 0 });
    observer.observe(arena);
    observer.observe(next);
    addEventListener('scroll', schedule, { passive: true });
    addEventListener('resize', schedule, { passive: true });
    [reduced, compact, forcedColours].forEach(query => query.addEventListener('change', updateMode));
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        if (frameId) cancelAnimationFrame(frameId);
        frameId = 0;
      } else updateMode();
    });
    if ('ResizeObserver' in window) {
      const resized = new ResizeObserver(schedule);
      resized.observe(arena);
      resized.observe(next);
    }
    updateMode();
  }
  if (document.hidden) {
    const startWhenVisible = () => {
      if (document.hidden) return;
      document.removeEventListener('visibilitychange', startWhenVisible);
      enhanceArena();
    };
    document.addEventListener('visibilitychange', startWhenVisible);
  } else enhanceArena();
})();
