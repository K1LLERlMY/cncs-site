/* A native photo viewer. Existing navigation and team dialogs keep their own locks. */
(() => {
  'use strict';

  function initializeGallery() {
    if (document.getElementById('cncs-gallery') ||
        typeof HTMLDialogElement === 'undefined' || !HTMLDialogElement.prototype.showModal) return;

    const selector = '.spirit-photo > div > img, .milestone-photo img';
    const motion = matchMedia('(prefers-reduced-motion: reduce)');
    const triggers = new WeakMap();
    const registered = new Set();
    let entries = [], activeIndex = 0, trigger = null, closing = false;
    let animation = null, animationRun = 0, imageRun = 0;

    const dialog = document.createElement('dialog');
    dialog.id = 'cncs-gallery';
    dialog.className = 'cncs-gallery';
    dialog.setAttribute('aria-labelledby', 'cncs-gallery-title');
    dialog.innerHTML = `
      <div class="gallery-shell">
        <header class="gallery-toolbar">
          <div><span class="gallery-kicker">CNCS / PHOTO ARCHIVE</span><h2 id="cncs-gallery-title">赛场影像</h2></div>
          <button class="gallery-close" type="button" autofocus aria-label="关闭照片，返回正文">关闭 <span aria-hidden="true">×</span></button>
        </header>
        <figure class="gallery-current" id="cncs-gallery-current">
          <div class="gallery-image-area"><span class="gallery-image-status">正在载入影像…</span></div>
          <figcaption class="gallery-caption">
            <div class="gallery-description" aria-live="polite" aria-atomic="true"><span class="gallery-counter"></span><p class="gallery-caption-text"></p></div>
            <a class="gallery-source" target="_blank" rel="noopener noreferrer">查看原始来源 <span aria-hidden="true">↗</span></a>
          </figcaption>
        </figure>
        <nav class="gallery-controls" aria-label="照片浏览">
          <button class="gallery-previous" type="button" aria-label="查看上一张照片" aria-controls="cncs-gallery-current"><span aria-hidden="true">←</span> 上一张</button>
          <span class="gallery-key-hint" aria-hidden="true">← → 切换 <i></i> ESC 关闭</span>
          <button class="gallery-next" type="button" aria-label="查看下一张照片" aria-controls="cncs-gallery-current">下一张 <span aria-hidden="true">→</span></button>
        </nav>
      </div>`;
    document.body.append(dialog);
    const shell = dialog.querySelector('.gallery-shell');
    const closeButton = dialog.querySelector('.gallery-close');
    const imageArea = dialog.querySelector('.gallery-image-area');
    const imageStatus = dialog.querySelector('.gallery-image-status');
    const figure = dialog.querySelector('.gallery-current');
    const counter = dialog.querySelector('.gallery-counter');
    const caption = dialog.querySelector('.gallery-caption-text');
    const source = dialog.querySelector('.gallery-source');
    const previous = dialog.querySelector('.gallery-previous');
    const next = dialog.querySelector('.gallery-next');

    function safeSource(value) {
      if (!value) return '';
      try {
        const url = new URL(value, document.baseURI);
        return /^https?:$/.test(url.protocol) ? url.href : '';
      } catch { return ''; }
    }

    function metadataFor(image) {
      const media = window.CNCS_HISTORY_MEDIA;
      const candidates = [
        ...Object.values(media?.covers || {}),
        ...Object.values(media?.moments || {}).flatMap(era => Object.values(era))
      ];
      return candidates.find(item => {
        try { return new URL(item.file, document.baseURI).href === image.src; }
        catch { return false; }
      });
    }

    function detailsFor(image) {
      const originalCaption = image.closest('figure')?.querySelector('figcaption');
      const sourceLink = originalCaption?.querySelector('a[href]');
      const copy = originalCaption?.cloneNode(true);
      copy?.querySelectorAll('a').forEach(link => link.remove());
      const text = copy ? [...copy.childNodes].map(node => node.textContent.trim()).filter(Boolean).join(' ') : '';
      const metadata = metadataFor(image);
      return {
        src: image.currentSrc || image.src,
        alt: image.alt || metadata?.alt || '',
        caption: text || metadata?.caption || image.alt || '',
        source: safeSource(sourceLink?.href || metadata?.sourcePage || ''),
        credit: sourceLink?.title || metadata?.credit || ''
      };
    }

    function cancelAnimation() {
      animation?.cancel();
      animation = null;
    }

    function renderImage(direction = 0) {
      const details = detailsFor(entries[activeIndex]);
      const run = ++imageRun;
      counter.textContent = `${String(activeIndex + 1).padStart(2, '0')} / ${String(entries.length).padStart(2, '0')}`;
      counter.setAttribute('aria-label', `第 ${activeIndex + 1} 张，共 ${entries.length} 张`);
      caption.textContent = details.caption;
      source.hidden = !details.source;
      if (details.source) source.href = details.source;
      else source.removeAttribute('href');
      source.title = details.credit;
      previous.disabled = next.disabled = entries.length < 2;
      figure.setAttribute('aria-busy', 'true');
      imageStatus.textContent = '正在载入影像…';
      imageStatus.hidden = false;

      const image = new Image();
      image.className = 'gallery-image';
      image.alt = details.alt;
      image.decoding = 'async';
      image.addEventListener('load', () => {
        if (run !== imageRun) return;
        figure.setAttribute('aria-busy', 'false');
        imageStatus.hidden = true;
        if (!motion.matches && direction && image.animate) {
          image.animate([
            { opacity: .35, transform: `translateX(${direction * 12}px)` },
            { opacity: 1, transform: 'translateX(0)' }
          ], { duration: 210, easing: 'cubic-bezier(.22,1,.36,1)' });
        }
      }, { once: true });
      image.addEventListener('error', () => {
        if (run !== imageRun) return;
        figure.setAttribute('aria-busy', 'false');
        image.hidden = true;
        imageStatus.textContent = details.source ? '暂时无法载入照片，可通过下方来源查看。' : '暂时无法载入照片，请稍后重试。';
      }, { once: true });
      imageArea.replaceChildren(image, imageStatus);
      image.src = details.src;
    }

    function openGallery(image, button) {
      // A background trigger must never replace or close another modal.
      if (dialog.open || document.querySelector('dialog[open]')) return;
      for (const item of registered) if (!item.isConnected) registered.delete(item);
      entries = [...registered].sort((a, b) => {
        if (a === b) return 0;
        return a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
      });
      activeIndex = entries.indexOf(image);
      if (activeIndex < 0) return;
      const run = ++animationRun;
      trigger = button;
      closing = false;
      renderImage();
      try { dialog.showModal(); }
      catch { trigger = null; return; }
      // Never toggle app.js's dialog-open class: each feature owns its lock.
      document.body.classList.add('cncs-gallery-open');
      closeButton.focus({ preventScroll: true });
      if (!motion.matches && shell.animate) {
        animation = shell.animate([
          { opacity: 0, transform: 'translateY(14px) scale(.99)' },
          { opacity: 1, transform: 'translateY(0) scale(1)' }
        ], { duration: 260, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'both' });
        animation.finished.catch(() => {}).then(() => {
          if (run === animationRun) cancelAnimation();
        });
      }
    }

    function afterClose() {
      if (dialog.open) return; // Ignore a queued close event after a reopen.
      ++animationRun;
      ++imageRun;
      cancelAnimation();
      closing = false;
      document.body.classList.remove('cncs-gallery-open');
      const returnTarget = trigger;
      trigger = null;
      if (!document.querySelector('dialog[open]') && returnTarget?.isConnected) {
        returnTarget.focus({ preventScroll: true });
      }
    }

    async function closeGallery() {
      if (!dialog.open || closing) return;
      closing = true;
      const run = ++animationRun;
      const current = getComputedStyle(shell);
      const start = { opacity: current.opacity, transform: current.transform };
      cancelAnimation();
      if (!motion.matches && shell.animate) {
        animation = shell.animate([start, { opacity: 0, transform: 'translateY(8px) scale(.995)' }], {
          duration: 170, easing: 'ease-in', fill: 'both'
        });
        await animation.finished.catch(() => {});
      }
      if (run !== animationRun || !dialog.open) return;
      dialog.close();
      afterClose();
    }

    function move(direction) {
      if (!dialog.open || closing || entries.length < 2) return;
      activeIndex = (activeIndex + direction + entries.length) % entries.length;
      renderImage(direction);
    }

    function register(image) {
      if (!image.matches(selector) || triggers.has(image)) return;
      const host = image.parentElement;
      if (!host || host.closest('a, button')) return;
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'gallery-open-button';
      button.setAttribute('aria-label', `放大照片：${image.alt || '赛场影像'}`);
      button.setAttribute('aria-haspopup', 'dialog');
      button.setAttribute('aria-controls', dialog.id);
      button.innerHTML = '<span aria-hidden="true">↗</span><span>放大</span>';
      button.addEventListener('click', () => openGallery(image, button));
      host.classList.add('cncs-gallery-target');
      host.append(button);
      triggers.set(image, button);
      registered.add(image);
    }

    closeButton.addEventListener('click', closeGallery);
    previous.addEventListener('click', () => move(-1));
    next.addEventListener('click', () => move(1));
    dialog.addEventListener('cancel', event => { event.preventDefault(); closeGallery(); });
    dialog.addEventListener('close', afterClose);
    dialog.addEventListener('keydown', event => {
      if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey ||
          event.target.closest('input, textarea, select, [contenteditable="true"]')) return;
      if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
        event.preventDefault();
        move(event.key === 'ArrowLeft' ? -1 : 1);
      }
    });
    motion.addEventListener('change', () => {
      if (motion.matches) {
        dialog.getAnimations({ subtree: true }).forEach(active => {
          try { active.finish(); } catch { active.cancel(); }
        });
      }
    });

    document.querySelectorAll(selector).forEach(register);
    // Only these two static sections are watched. Feed updates and viewer changes
    // are outside the observer, and our own added buttons contain no images.
    const observer = new MutationObserver(records => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (node.matches('img')) register(node);
          else node.querySelectorAll('img').forEach(register);
        }
      }
    });
    document.querySelectorAll('#history, .spirit-photo').forEach(root => {
      observer.observe(root, { childList: true, subtree: true });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeGallery, { once: true });
  } else initializeGallery();
})();
