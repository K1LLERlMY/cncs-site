'use strict';
(() => {
  const root=document.documentElement,hero=document.querySelector('.hero'),stage=document.querySelector('.hero-stage');
  const video=document.getElementById('hero-video'),toggle=document.getElementById('video-toggle'),label=document.getElementById('video-state');
  const reduced=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
  const header=document.querySelector('.site-header'),spirit=document.querySelector('.spirit'),arena=document.querySelector('.arena');
  const shutters=[...document.querySelectorAll('.hero-shutters>span')],ink=[...document.querySelectorAll('.ink-line')];
  const signature=document.querySelector('.spirit-signature'),photo=document.querySelector('.spirit-photo'),footer=document.querySelector('.site-footer');
  const sections=[...document.querySelectorAll('main>section')],clamp=(value,min=0,max=1)=>Math.max(min,Math.min(max,value));
  let frame=0,heroVisible=false,startupReady=false,mediaReady=false,userPaused=reduced.matches||navigator.connection?.saveData||false;
  function videoUI(){const playing=!video.paused;toggle.setAttribute('aria-label',playing?'暂停背景视频':'播放背景视频');toggle.querySelector('.video-icon').textContent=playing?'Ⅱ':'▷';label.textContent=playing?'背景影片播放中':'播放背景影片';hero.classList.toggle('video-playing',playing);}
  function play(manual=false){
    if(!manual&&(!startupReady||!heroVisible||userPaused||document.hidden))return;
    if(!mediaReady){mediaReady=true;video.querySelectorAll('source[data-src]').forEach(source=>{source.src=source.dataset.src;});video.load();}
    video.play().then(videoUI).catch(videoUI);
  }
  toggle.addEventListener('click',()=>{userPaused=!video.paused;if(userPaused)video.pause();else play(true);videoUI();});
  video.addEventListener('playing',()=>{hero.classList.add('video-loaded');videoUI();});video.addEventListener('pause',videoUI);
  video.addEventListener('error',()=>{hero.classList.remove('video-loaded');label.textContent='影片暂不可用';toggle.disabled=true;});
  new IntersectionObserver(entries=>{heroVisible=entries[0].isIntersecting;if(!heroVisible)video.pause();else play();},{threshold:.05}).observe(stage);videoUI();
  // The real page stays usable during the short opening; no artificial loading gate.
  document.querySelectorAll('.title-line>span').forEach((line,row)=>{
    const fragment=document.createDocumentFragment();
    [...line.textContent].forEach((letter,index)=>{const char=document.createElement('span');char.className='hero-char';char.textContent=letter;char.style.setProperty('--char',index+row*3);if(letter==='.')char.classList.add('title-period');fragment.append(char);});line.replaceChildren(fragment);
  });
  root.classList.add('motion-enhanced');
  requestAnimationFrame(()=>requestAnimationFrame(()=>{root.classList.add('intro-complete');startupReady=true;play();schedule();}));
  const reveal=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('motion-visible','line-visible');reveal.unobserve(entry.target);}}),{threshold:.08,rootMargin:'0px 0px -30px 0px'});
  document.querySelectorAll('.section-kicker').forEach(element=>reveal.observe(element));
  document.querySelectorAll('.section-heading h2,.section-heading>p,.spirit-copy,.team-card,.next-grid h2,.next-grid>div,.live-toolbar').forEach((element,index)=>{element.dataset.motionReveal='';element.style.setProperty('--reveal-delay',`${element.matches('.team-card')?[...element.parentElement.children].indexOf(element)*90:(index%2)*90}ms`);reveal.observe(element);});
  // Batch geometry reads before style writes; no continuously running scroll loop.
  function render(){
    frame=0;if(document.hidden)return;
    const vh=innerHeight,y=scrollY,total=root.scrollHeight-vh;
    const heroBox=hero.getBoundingClientRect(),spiritBox=spirit.getBoundingClientRect(),arenaBox=arena.getBoundingClientRect(),footerBox=footer.getBoundingClientRect(),titleBox=document.getElementById('spirit-title').getBoundingClientRect();
    const active=sections.map(section=>({section,box:section.getBoundingClientRect()})).find(({box})=>box.top<=80&&box.bottom>80);
    root.style.setProperty('--reading',`${clamp(y/Math.max(total,1))*100}%`);
    header.classList.toggle('on-light',!!active&&(active.section.matches('.section-light')||(active.section===hero&&-heroBox.top>vh*.62)));
    if(reduced.matches)return;
    const p=clamp(-heroBox.top/Math.max(heroBox.height-vh,1));
    hero.style.setProperty('--hero-p',p.toFixed(4));hero.style.setProperty('--film-scale',(1-p*.08).toFixed(4));hero.style.setProperty('--video-scale',(1.06+p*.18).toFixed(4));hero.style.setProperty('--video-y',`${p*35}px`);hero.style.setProperty('--title-x',`${-p*150}px`);hero.style.setProperty('--hero-title-opacity',clamp(1-p*1.15).toFixed(4));hero.style.setProperty('--end-opacity',clamp((p-.68)/.2).toFixed(4));hero.style.setProperty('--end-y',`${(1-clamp((p-.65)/.3))*35}px`);
    const shutterCount=innerWidth<=700?3:5;shutters.forEach((shutter,index)=>shutter.style.setProperty('--shutter',clamp((p-.13-(index%shutterCount)*.045)/.56).toFixed(4)));
    const reading=clamp((vh*.86-titleBox.top)/(vh*.54));ink.forEach((line,index)=>line.style.setProperty('--ink-fill',`${clamp(reading*1.65-index*.48)*100}%`));
    const story=clamp((vh-spiritBox.top)/(vh+spiritBox.height));photo.style.setProperty('--photo-y',`${45-story*95}px`);photo.style.setProperty('--photo-rotate',`${-5+story*8}deg`);photo.style.setProperty('--photo-scale',(1.18-story*.16).toFixed(3));signature.style.setProperty('--marquee-x',`${-story*innerWidth*.25}px`);
    if(arenaBox.top<vh&&arenaBox.bottom>0){const a=clamp(-arenaBox.top/Math.max(arenaBox.height-vh,1)),enter=clamp((vh-arenaBox.top)/(vh*.85));arena.style.setProperty('--arena-inset',`${(1-enter)*6}%`);arena.style.setProperty('--arena-scale',(1.18-a*.12).toFixed(3));arena.style.setProperty('--arena-y',`${-a*75}px`);arena.style.setProperty('--arena-title-x',`${(1-enter)*80-a*35}px`);}
    footer.style.setProperty('--footer-y',`${clamp(footerBox.top/vh)*80}px`);
  }
  function schedule(){if(!frame)frame=requestAnimationFrame(render);}
  addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule,{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)video.pause();else{play();schedule();}});
  reduced.addEventListener('change',()=>{if(reduced.matches){userPaused=true;video.pause();}schedule();});
  if('ResizeObserver' in window)new ResizeObserver(schedule).observe(document.querySelector('main'));
  document.fonts?.ready.then(schedule);document.addEventListener('load',schedule,true);
  const cursor=document.createElement('div');cursor.className='motion-cursor';cursor.textContent='查看 ↗';cursor.setAttribute('aria-hidden','true');document.body.append(cursor);
  let cursorFrame=0,cursorX=0,cursorY=0;
  document.querySelectorAll('.team-card').forEach(card=>{
    card.addEventListener('pointerenter',()=>{if(fine.matches&&!reduced.matches)cursor.classList.add('is-active');});
    card.addEventListener('pointermove',event=>{if(!fine.matches||reduced.matches)return;cursorX=event.clientX-37;cursorY=event.clientY-37;if(!cursorFrame)cursorFrame=requestAnimationFrame(()=>{cursor.style.transform=`translate3d(${cursorX}px,${cursorY}px,0)`;cursorFrame=0;});});
    card.addEventListener('pointerleave',()=>cursor.classList.remove('is-active'));card.addEventListener('click',()=>cursor.classList.remove('is-active'));
  });
  document.querySelectorAll('.pill-link,.text-link').forEach(link=>{
    link.addEventListener('pointermove',event=>{if(!fine.matches||reduced.matches)return;const box=link.getBoundingClientRect();link.style.setProperty('--magnet-x',`${(event.clientX-box.left-box.width/2)*.09}px`);link.style.setProperty('--magnet-y',`${(event.clientY-box.top-box.height/2)*.13}px`);});
    link.addEventListener('pointerleave',()=>{link.style.setProperty('--magnet-x','0px');link.style.setProperty('--magnet-y','0px');});
  });schedule();
})();
