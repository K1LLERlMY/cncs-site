'use strict';
(() => {
  const root=document.documentElement,hero=document.querySelector('.hero'),stage=document.querySelector('.hero-stage');
  const video=document.getElementById('hero-video'),toggle=document.getElementById('video-toggle'),label=document.getElementById('video-state');
  const reduced=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
  const header=document.querySelector('.site-header'),spirit=document.querySelector('.spirit'),arena=document.querySelector('.arena');
  const shutters=[...document.querySelectorAll('.hero-shutters>span')],ink=[...document.querySelectorAll('.ink-line')];
  const signature=document.querySelector('.spirit-signature'),photo=document.querySelector('.spirit-photo'),footer=document.querySelector('.site-footer');
  const sections=[...document.querySelectorAll('main>section')],clamp=(value,min=0,max=1)=>Math.max(min,Math.min(max,value));
  const chapterNames=['序章','热爱','编年史','中国战队','我们的主场','下一回合','赛程与战绩'];
  const rail=document.createElement('nav');rail.className='chapter-rail';rail.setAttribute('aria-label','阅读章节');
  const chapterLinks=sections.map((section,index)=>{
    const link=document.createElement('a');link.href=`#${section.id}`;link.setAttribute('aria-label',`跳至${chapterNames[index]}`);
    const number=document.createElement('b');number.textContent=index===6?'NOW':String(index).padStart(2,'0');number.setAttribute('aria-hidden','true');
    const name=document.createElement('span');name.textContent=chapterNames[index];name.setAttribute('aria-hidden','true');link.append(number,name);rail.append(link);return link;
  });
  document.body.append(rail);
  let lastChapter=-1;
  const timelines=[...document.querySelectorAll('.history .milestones')];
  let frame=0,heroVisible=false,startupReady=false,mediaReady=false,userPaused=reduced.matches||navigator.connection?.saveData||false;
  function videoUI(){const playing=!video.paused;toggle.setAttribute('aria-label',playing?'暂停背景视频':'播放背景视频');toggle.querySelector('.video-icon').textContent=playing?'Ⅱ':'▷';label.textContent=playing?'背景影片播放中':'播放背景影片';hero.classList.toggle('video-playing',playing);}
  function play(manual=false){
    if(!manual&&(!startupReady||!heroVisible||userPaused||document.hidden))return;
    if(!mediaReady){mediaReady=true;video.querySelectorAll('source[data-src]').forEach(source=>{source.src=source.dataset.src;});video.load();}
    video.play().then(videoUI).catch(videoUI);
  }
  toggle.addEventListener('click',()=>{userPaused=!video.paused;if(userPaused)video.pause();else play(true);videoUI();});
  video.addEventListener('playing',()=>{hero.classList.add('video-loaded');videoUI();});video.addEventListener('pause',videoUI);
  video.addEventListener('error',()=>{hero.classList.remove('video-loaded');label.textContent='影片暂不可用';toggle.disabled=true;});
  new IntersectionObserver(entries=>{heroVisible=entries[0].isIntersecting;if(!heroVisible)video.pause();else play();},{threshold:.05}).observe(stage);videoUI();
  // The real page stays usable during the short opening; no artificial loading gate.
  document.querySelectorAll('.title-line>span').forEach((line,row)=>{
    const fragment=document.createDocumentFragment();
    [...line.textContent].forEach((letter,index)=>{const char=document.createElement('span');char.className='hero-char';char.textContent=letter;char.style.setProperty('--char',index+row*3);if(letter==='.')char.classList.add('title-period');fragment.append(char);});line.replaceChildren(fragment);
  });
  root.classList.add('motion-enhanced');
  requestAnimationFrame(()=>requestAnimationFrame(()=>{root.classList.add('intro-complete');startupReady=true;play();schedule();}));
  const reveal=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('motion-visible','line-visible');reveal.unobserve(entry.target);}}),{threshold:.08,rootMargin:'0px 0px -30px 0px'});
  document.querySelectorAll('.section-kicker').forEach(element=>reveal.observe(element));
  document.querySelectorAll('.section-heading h2,.section-heading>p,.spirit-copy,.team-card,.next-grid h2,.next-grid>div,.live-toolbar').forEach((element,index)=>{element.dataset.motionReveal='';element.style.setProperty('--reveal-delay',`${element.matches('.team-card')?[...element.parentElement.children].indexOf(element)*90:(index%2)*90}ms`);reveal.observe(element);});
  // Batch geometry reads before style writes; no continuously running scroll loop.
  function render(){
    frame=0;if(document.hidden)return;
    const vh=innerHeight,y=scrollY,total=root.scrollHeight-vh;
    const boxes=new Map(sections.map(section=>[section,section.getBoundingClientRect()]));
    const heroBox=boxes.get(hero),spiritBox=boxes.get(spirit),arenaBox=boxes.get(arena),footerBox=footer.getBoundingClientRect();
    const titleBox=spiritBox.top<vh&&spiritBox.bottom>0?document.getElementById('spirit-title').getBoundingClientRect():null;
    const active=sections.find(section=>{const box=boxes.get(section);return box.top<=80&&box.bottom>80;});
    const chapter=sections.find(section=>{const box=boxes.get(section);return box.top<=vh*.4&&box.bottom>vh*.4;})||active||sections[sections.length-1],chapterIndex=sections.indexOf(chapter);
    const timelineBoxes=timelines.map(element=>({element,box:element.getBoundingClientRect()}));
    root.style.setProperty('--reading',`${clamp(y/Math.max(total,1))*100}%`);
    header.classList.toggle('on-light',!!active&&(active.matches('.section-light')||(active===hero&&-heroBox.top>Math.max(heroBox.height-vh,1)*.16)));
    rail.classList.toggle('on-light',chapter.matches('.section-light')||(chapter===hero&&-heroBox.top>Math.max(heroBox.height-vh,1)*.16));
    if(chapterIndex!==lastChapter){chapterLinks.forEach((link,index)=>{if(index===chapterIndex)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');});lastChapter=chapterIndex;}
    const chapterBox=boxes.get(chapter);rail.style.setProperty('--chapter-read',clamp((vh*.4-chapterBox.top)/Math.max(chapterBox.height,1)).toFixed(4));
    timelineBoxes.forEach(({element,box})=>{if(box.top<vh&&box.bottom>0)element.style.setProperty('--timeline-read',clamp((vh*.5-box.top)/Math.max(box.height,1)).toFixed(4));});
    if(reduced.matches)return;
    if(heroBox.bottom>0&&heroBox.top<vh){
    const p=clamp(-heroBox.top/Math.max(heroBox.height-vh,1));
    hero.style.setProperty('--hero-p',p.toFixed(4));hero.style.setProperty('--film-scale',(1-p*.08).toFixed(4));hero.style.setProperty('--video-scale',(1.06+p*.18).toFixed(4));hero.style.setProperty('--video-y',`${p*35}px`);hero.style.setProperty('--title-x',`${-p*150}px`);hero.style.setProperty('--hero-title-opacity',clamp(1-p*1.15).toFixed(4));hero.style.setProperty('--end-opacity',clamp((p-.68)/.2).toFixed(4));hero.style.setProperty('--end-y',`${(1-clamp((p-.65)/.3))*35}px`);
    hero.style.setProperty('--seal-turn',`${(p*100).toFixed(2)}deg`);hero.style.setProperty('--type-fill',`${clamp(p*2)*100}%`);
    const shutterCount=innerWidth<=700?3:5;shutters.forEach((shutter,index)=>shutter.style.setProperty('--shutter',clamp((p-.13-(index%shutterCount)*.045)/.56).toFixed(4)));
    }
    if(titleBox){
    const reading=clamp((vh*.86-titleBox.top)/(vh*.54));ink.forEach((line,index)=>line.style.setProperty('--ink-fill',`${clamp(reading*1.65-index*.48)*100}%`));
    const story=clamp((vh-spiritBox.top)/(vh+spiritBox.height));photo.style.setProperty('--photo-y',`${45-story*95}px`);photo.style.setProperty('--photo-rotate',`${-5+story*8}deg`);photo.style.setProperty('--photo-scale',(1.18-story*.16).toFixed(3));signature.style.setProperty('--marquee-x',`${-story*innerWidth*.25}px`);
    }
    if(arenaBox.top<vh&&arenaBox.bottom>0){const a=clamp(-arenaBox.top/Math.max(arenaBox.height-vh,1)),enter=clamp((vh-arenaBox.top)/(vh*.85));arena.style.setProperty('--arena-inset',`${(1-enter)*6}%`);arena.style.setProperty('--arena-scale',(1.18-a*.12).toFixed(3));arena.style.setProperty('--arena-y',`${-a*75}px`);arena.style.setProperty('--arena-title-x',`${(1-enter)*80-a*35}px`);}
    footer.style.setProperty('--footer-y',`${clamp(footerBox.top/vh)*80}px`);
  }
  function schedule(){if(!frame)frame=requestAnimationFrame(render);}
  addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule,{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)video.pause();else{play();schedule();}});
  reduced.addEventListener('change',()=>{if(reduced.matches){userPaused=true;video.pause();}schedule();});
  if('ResizeObserver' in window)new ResizeObserver(schedule).observe(document.querySelector('main'));
  document.fonts?.ready.then(schedule);document.addEventListener('load',schedule,true);
  // Small depth offsets follow a real pointer only; native scrolling remains untouched.
  let lookFrame=0,lookX=0,lookY=0;
  function resetLook(){lookX=0;lookY=0;if(lookFrame){cancelAnimationFrame(lookFrame);lookFrame=0;}hero.style.setProperty('--look-x','0px');hero.style.setProperty('--look-y','0px');}
  stage.addEventListener('pointermove',event=>{
    if(!fine.matches||reduced.matches||document.hidden||event.pointerType==='touch'||scrollY>innerHeight*.25)return;
    lookX=(event.clientX/innerWidth-.5)*28;lookY=(event.clientY/innerHeight-.5)*18;
    if(!lookFrame)lookFrame=requestAnimationFrame(()=>{lookFrame=0;hero.style.setProperty('--look-x',`${lookX.toFixed(2)}px`);hero.style.setProperty('--look-y',`${lookY.toFixed(2)}px`);});
  },{passive:true});
  stage.addEventListener('pointerleave',resetLook);fine.addEventListener('change',resetLook);reduced.addEventListener('change',resetLook);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)resetLook();});
  const cursor=document.createElement('div');cursor.className='motion-cursor';cursor.textContent='查看 ↗';cursor.setAttribute('aria-hidden','true');document.body.append(cursor);
  let cursorFrame=0,cursorX=0,cursorY=0;
  addEventListener('scroll',()=>{cursor.classList.remove('is-active');if(scrollY>innerHeight*.25&&(lookX||lookY))resetLook();},{passive:true});
  document.querySelectorAll('.team-card').forEach(card=>{
    card.addEventListener('pointerenter',()=>{if(fine.matches&&!reduced.matches)cursor.classList.add('is-active');});
    card.addEventListener('pointermove',event=>{if(!fine.matches||reduced.matches)return;cursorX=event.clientX-37;cursorY=event.clientY-37;if(!cursorFrame)cursorFrame=requestAnimationFrame(()=>{cursor.style.transform=`translate3d(${cursorX}px,${cursorY}px,0)`;cursorFrame=0;});});
    card.addEventListener('pointerleave',()=>cursor.classList.remove('is-active'));card.addEventListener('click',()=>cursor.classList.remove('is-active'));
  });
  document.querySelectorAll('.pill-link,.text-link').forEach(link=>{
    link.addEventListener('pointermove',event=>{if(!fine.matches||reduced.matches)return;const box=link.getBoundingClientRect();link.style.setProperty('--magnet-x',`${(event.clientX-box.left-box.width/2)*.09}px`);link.style.setProperty('--magnet-y',`${(event.clientY-box.top-box.height/2)*.13}px`);});
    link.addEventListener('pointerleave',()=>{link.style.setProperty('--magnet-x','0px');link.style.setProperty('--magnet-y','0px');});
  });schedule();
})();
